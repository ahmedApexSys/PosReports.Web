import{N as U}from"./chunk-JISE2KAE.js";import{a as B,f as W}from"./chunk-EQDQRRRY.js";var m="#A81813";var nt="#ffffff",S="#FCE0DE",rt="#FEF2F1",it="#FAF7F7",y="#e6d9d8",at="#1f2937",j="#6b7280",st="#dcfce7",lt="#166534",pt="#fee2e2",dt="#991b1b",ct={takeaway:"T.Away",takeaways:"T.Away",takaway:"T.Away",takeout:"T.Out",dinein:"DineIn",delivery:"Deliv.",delivered:"Deliv.",deliveries:"Deliv.",reservation:"Resv.",reservations:"Resv.",reserve:"Resv.",pickup:"Pickup",hosbitality:"Hosp.",hospitality:"Hosp."},N=new Set(["transaction","transactionname","paymentstatus","payway"]);function gt(w){let r=e=>(e??"").trim().toLowerCase().replace(/[\s._-]/g,"");return w.key&&N.has(r(w.key))?!0:!w.key&&(N.has(r(w.headerEn))||N.has(r(w.headerAr)))}var _=class w{excel(r,e,t){let i=this.buildHtml(r,e,t,"excel"),s=new Blob(["\uFEFF"+i],{type:"application/vnd.ms-excel;charset=utf-8"});this.download(s,this.fileName(t,"xls"))}csv(r,e,t){let i=l=>'"'+String(l??"").replace(/"/g,'""')+'"',s=e.map(l=>i(`${t.lang==="ar"?l.headerAr:l.headerEn}${l.headerEn&&l.headerAr?` / ${t.lang==="ar"?l.headerEn:l.headerAr}`:""}`)),n=[];n.push(i(t.lang==="ar"?t.titleAr:t.titleEn));for(let l of this.metaLines(t))n.push(i(l));n.push(""),n.push(s.join(","));for(let l of r)n.push(e.map(c=>i(c.value(l,t.lang))).join(","));t.footer&&t.footer.length===e.length&&n.push(t.footer.map(l=>i(l)).join(","));let f=new Blob(["\uFEFF"+n.join(`\r
`)],{type:"text/csv;charset=utf-8"});this.download(f,this.fileName(t,"csv"))}pdf(r,e,t){let i=t.paper??"a4",s=i==="pos72"||i==="pos80"||i==="flash"?this.buildReceipt(r,e,t,i):this.buildHtml(r,e,t,i);this.printHtml(s)}printHtml(r){let e=document.createElement("iframe");Object.assign(e.style,{position:"fixed",right:"0",bottom:"0",width:"0",height:"0",border:"0"}),document.body.appendChild(e);let t=e.contentWindow?.document;if(!t){e.remove();return}t.open(),t.write(r),t.close();let i=e.contentWindow,s=()=>{try{i?.focus(),i?.print()}catch(n){}setTimeout(()=>e.remove(),6e4)};t.readyState==="complete"?setTimeout(s,300):e.onload=()=>setTimeout(s,300)}totalReport(r,e,t){this.printHtml(this.buildTotalReceipt(r,e,t))}buildTotalReceipt(r,e,t){let i=e.lang==="ar",s=i?"rtl":"ltr",n=(d,u)=>i?u:d,f=t==="pos72"?"72mm":"80mm",l=i?e.titleAr:e.titleEn,c=`${a((e.fromDate||"").slice(0,10))} \u2192 ${a((e.toDate||"").slice(0,10))}`,x=d=>{let u=d.head.map(($,o)=>`<th class="${o>0?"num":""}">${a($)}</th>`).join(""),b=d.rows.length?d.rows.map($=>`<tr>${$.map((o,g)=>`<td class="${g>0?"num":""}">${a(o)}</td>`).join("")}</tr>`).join(""):`<tr><td colspan="${d.head.length}" class="empty">\u2014</td></tr>`;return`<table><thead><tr>${u}</tr></thead><tbody>${b}</tbody></table>`},h=d=>`<div class="kv ${d.strong?"st":""}"><span>${a(d.label)}</span><span>${a(d.value)}</span></div>`,E=r.map(d=>{if(d.heading)return`<div class="sec-head">${a(d.title)}</div>`;if(d.boxed){let b=(d.rows??[]).map(h).join("");return`<div class="cat"><div class="cat-t">${a(d.title)}</div>${b}</div>${d.table?x(d.table):""}`}let u=`<div class="sec">${a(d.title)}</div>`;return d.rows&&(u+=d.rows.map(h).join("")),d.table&&(u+=x(d.table)),u}).join("");return`<!doctype html>
<html dir="${s}" lang="${e.lang}">
<head><meta charset="utf-8"><title>${a(l)}</title>
<style>
  @page { size: ${f} auto; margin: 3mm; }
  @media print { body { -webkit-print-color-adjust:exact; print-color-adjust:exact } }
  * { box-sizing:border-box; }
  body { font-family:'Tajawal','Segoe UI',Arial,sans-serif; margin:0 auto; padding:6px; color:#000;
         width:${f}; font-size:12.5px; line-height:1.34; font-weight:600; }
  .r-head { text-align:center; border:2px solid #000; border-radius:8px; padding:9px 6px; margin-bottom:8px; }
  .r-head .logo { display:inline-flex; height:26px; width:26px; align-items:center; justify-content:center;
                  border-radius:6px; background:#000; color:#fff; font-weight:800; font-size:16px; margin-bottom:4px;
                  -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  .r-head h1 { margin:2px 0 0; font-size:18px; font-weight:800; color:#000; }
  .r-head .sub { margin-top:2px; color:#000; font-size:11px; font-weight:700; }
  .m-row { display:flex; justify-content:space-between; gap:8px; padding:2px; font-size:12px; }
  .m-row span { color:#000; font-weight:700; } .m-row b { color:#000; font-weight:800; }
  .rule { border:0; border-top:2px solid #000; margin:7px 0; }
  .sec { margin:9px 0 2px; font-size:12.5px; font-weight:800; text-transform:uppercase; letter-spacing:.3px;
         color:#000; border-bottom:2px solid #000; padding-bottom:2px; }
  .sec-head { margin:11px 0 3px; font-size:13.5px; font-weight:800; text-transform:uppercase; text-align:center;
              color:#000; border-top:2px solid #000; border-bottom:2px solid #000; padding:3px 0; }
  .kv { display:flex; justify-content:space-between; gap:10px; padding:3px 2px; font-size:12.5px; font-weight:700; color:#000;
        border-bottom:1px dashed #000; }
  .kv span:last-child { font-variant-numeric:tabular-nums; font-weight:800; }
  .kv.st { font-size:15px; font-weight:800; border-bottom:0; border-top:2px solid #000; margin-top:3px; padding-top:5px; }
  .cat { border:2px solid #000; border-radius:6px; padding:5px 7px; margin:5px 0 3px; }
  .cat-t { text-align:center; font-size:13px; font-weight:800; text-transform:uppercase; margin-bottom:3px; }
  table { width:100%; border-collapse:collapse; table-layout:fixed; margin:1px 0 4px; }
  thead th { font-size:10px; text-transform:uppercase; color:#000; font-weight:800; padding:4px 2px;
             border-bottom:2px solid #000; text-align:${i?"right":"left"}; white-space:normal; overflow-wrap:anywhere; }
  tbody td { padding:4px 2px; border-bottom:1px dashed #000; font-size:11.5px; font-weight:700; color:#000;
             text-align:${i?"right":"left"}; white-space:normal; overflow-wrap:anywhere; }
  th.num, td.num { text-align:${i?"left":"right"}; font-variant-numeric:tabular-nums; white-space:nowrap; overflow-wrap:normal; }
  td.empty { text-align:center; color:#000; font-weight:600; }
  .r-foot { text-align:center; color:#000; font-size:11px; font-weight:700; margin-top:12px; border-top:2px solid #000; padding-top:5px; }
</style></head>
<body dir="${s}">
  <div class="r-head">
    <div class="logo">A</div>
    <h1>${a(l)}</h1>
    ${e.companyName?`<div class="sub">${a(e.companyName)}${e.branchName?" \xB7 "+a(e.branchName):""}</div>`:""}
  </div>
  <div class="r-meta">
    ${e.companyName?`<div class="m-row"><span>${n("Company","\u0627\u0644\u0634\u0631\u0643\u0629")}</span><b>${a(e.companyName)}</b></div>`:""}
    ${e.branchName?`<div class="m-row"><span>${n("Branch","\u0627\u0644\u0641\u0631\u0639")}</span><b>${a(e.branchName)}</b></div>`:""}
    <div class="m-row"><span>${n("Period","\u0627\u0644\u0641\u062A\u0631\u0629")}</span><b>${c}</b></div>
  </div>
  <hr class="rule">
  ${E}
  <div class="r-foot">Apex Point of Sale \u2014 ${n("Thank you","\u0634\u0643\u0631\u0627\u064B \u0644\u0643")}</div>
</body>
</html>`}pdfDownload(r,e,t){return W(this,null,function*(){if(t.lang==="ar"){this.pdf(r,e,t);return}try{let{jsPDF:i}=yield import("./chunk-YVHQLHF2.js"),s=(yield import("./chunk-JMMNUY4S.js")).default,n=new i({orientation:"landscape",unit:"pt",format:"a4"}),f=n.internal.pageSize.getWidth(),l=n.internal.pageSize.getHeight(),c=28;n.setFont("helvetica","bold"),n.setFontSize(15),n.setTextColor(168,24,19),n.text(t.titleEn||t.fileBase||"Report",c,30);let x=38;t.subtitleEn&&(n.setFont("helvetica","normal"),n.setFontSize(9),n.setTextColor(120,120,120),n.text(t.subtitleEn,c,x),x+=8),n.setDrawColor(168,24,19),n.setLineWidth(1.5),n.line(c,x,f-c,x),x+=12,n.setFont("helvetica","normal"),n.setFontSize(8.5),n.setTextColor(90,90,90);for(let o of this.metaLines(t))n.text(o,c,x,{maxWidth:f-c*2}),x+=11;let h=[e.map(o=>o.headerEn||o.headerAr||"")],E=r.map(o=>e.map(g=>String(g.value(o,"en")??""))),d=t.footer&&t.footer.length===e.length?[t.footer.map(o=>String(o??""))]:void 0,u={};e.forEach((o,g)=>{u[g]={halign:o.numeric?"right":"left"}}),s(n,{head:h,body:E,foot:d,startY:x+2,margin:{left:c,right:c,bottom:26},tableWidth:"auto",styles:{font:"helvetica",fontSize:7,cellPadding:3,overflow:"linebreak",lineColor:[230,217,216],lineWidth:.5,textColor:[31,41,55],valign:"middle"},headStyles:{fillColor:[168,24,19],textColor:[255,255,255],fontStyle:"bold",halign:"center",fontSize:7,lineColor:[168,24,19]},footStyles:{fillColor:[254,242,241],textColor:[168,24,19],fontStyle:"bold"},alternateRowStyles:{fillColor:[250,247,247]},columnStyles:u,didDrawPage:()=>{let o=n.getNumberOfPages();n.setFont("helvetica","normal"),n.setFontSize(7),n.setTextColor(150,150,150),n.text(`${t.titleEn||""}  \xB7  ${this.nowLabel()}  \xB7  ${o}`,c,l-12)}});let b=t.summary,$=()=>n.lastAutoTable?.finalY??x;if(b&&(b.figures.length||b.payways.length)){n.setFont("helvetica","bold"),n.setFontSize(10),n.setTextColor(168,24,19),n.text("Summary",c,$()+18);let o={styles:{font:"helvetica",fontSize:7,cellPadding:3,halign:"center",lineColor:[230,217,216],lineWidth:.5,textColor:[31,41,55]},headStyles:{fillColor:[252,224,222],textColor:[168,24,19],fontStyle:"bold",halign:"center",fontSize:7},margin:{left:c,right:c,bottom:26},tableWidth:"auto"};b.figures.length&&s(n,B({head:[b.figures.map(g=>g.label)],body:[b.figures.map(g=>g.value)],startY:$()+24},o)),b.payways.length&&s(n,B({head:[["PayWay","Total","Net"]],body:b.payways.map(g=>[g.payway,g.total,g.net]),startY:$()+8},o))}n.save(this.fileName(t,"pdf"))}catch(i){console.error("[ExportService] vector PDF failed, falling back to print:",i),this.pdf(r,e,t)}})}buildHtml(r,e,t,i){let s=t.lang==="ar",n=s?"rtl":"ltr",f=i==="excel",l=i==="pos72"||i==="pos80",c=s?t.titleAr:t.titleEn,x=s?t.subtitleAr||t.subtitleEn:t.subtitleEn||t.subtitleAr,h=(p,T)=>s?T:p,E=f?m:S,d=f?nt:m,u=[];t.branch&&u.push(`${h("Branch","\u0627\u0644\u0641\u0631\u0639")}: <b>${a(t.branch)}</b>`),(t.fromDate||t.toDate)&&u.push(`${h("Period","\u0627\u0644\u0641\u062A\u0631\u0629")}: <b>${a((t.fromDate||"").slice(0,10))} \u2192 ${a((t.toDate||"").slice(0,10))}</b>`),u.push(`${h("Rows","\u0639\u062F\u062F \u0627\u0644\u0633\u062C\u0644\u0627\u062A")}: <b>${r.length}</b>`),u.push(`${h("Generated","\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u0635\u062F\u064A\u0631")}: <b>${a(this.nowLabel())}</b>`);let b=(t.appliedFilters??[]).filter(p=>p&&p.value&&String(p.value).trim()!=="").map(p=>`<span class="chip"><i>${a(p.label)}</i>${a(p.value)}</span>`).join(""),$=b?`<div class="filters"><span class="filters-lead">${h("Filters","\u0627\u0644\u0641\u0644\u0627\u062A\u0631")}:</span>${b}</div>`:"",o=i==="a4",g=e.length,C=g>=18?8:g>=14?9:g>=11?10:12,G=l?9:o?C:12,v=l?"3px 4px":o?"4px 6px":"6px 10px",P=l||o?"normal":"nowrap",F=o?"overflow-wrap:anywhere;word-break:break-word;":"",L=p=>f?Math.max(p.width??18,p.numeric?12:20)*8:(p.width??18)*7,H=p=>f&&!p.numeric?"mso-number-format:'\\@';":"",Y=e.map(p=>{let T=s?p.headerAr:p.headerEn,k=s?p.headerEn:p.headerAr,I=!l&&k&&k!==T?`<div style="font-weight:400;font-size:10px;opacity:.75">${a(k)}</div>`:"",A=f?`width:${L(p)}px;`:"";return`<th style="background:${E};color:${d};border:1px solid ${f?m:y};border-bottom:2px solid ${m};padding:${v};text-align:center;font-weight:700;white-space:${P};${F}${A}">${a(T)}${I}</th>`}).join(""),X=r.map((p,T)=>{let k=T%2?` background:${it};`:"";return`<tr>${e.map(A=>{let et=A.value(p,t.lang),R=A.tone?.(p),D="";R==="good"?D=`background:${st};color:${lt};font-weight:600;`:R==="bad"?D=`background:${pt};color:${dt};font-weight:600;`:R==="muted"&&(D=`color:${j};`);let ot=A.numeric||s?"right":"left";return`<td style="border:1px solid ${y};padding:${v};text-align:${ot};vertical-align:top;white-space:${P};${F}${H(A)}${k}${D}">${a(et)}</td>`}).join("")}</tr>`}).join(""),K=t.footer&&t.footer.length===e.length?`<tfoot><tr>${e.map((p,T)=>{let k=p.numeric||s?"right":"left";return`<td style="border:1px solid ${y};border-top:2px solid ${m};background:${rt};padding:${v};text-align:${k};font-weight:700;color:${m};white-space:${P};${F}${H(p)}">${a(t.footer[T])}</td>`}).join("")}</tr></tfoot>`:"",Z=o?"":e.map(p=>`<col style="width:${L(p)}px">`).join(""),q=i==="pos72"?"72mm auto":i==="pos80"?"80mm auto":"A4 landscape",J=l?"3mm":"12mm",Q=l?"6px":"18px",V=f?"":`
      @page { size: ${q}; margin: ${J}; }
      @media print { .noprint { display:none } body { -webkit-print-color-adjust:exact; print-color-adjust:exact } }
      .hint { margin: 8px 0 14px; color:${j}; font-size:12px }
    `,z=t.summary,M=z&&z.figures.length?`<table style="margin-top:14px"><thead><tr>${z.figures.map(p=>`<th style="border:1px solid ${y};background:${S};color:${m};padding:${v};text-align:center;font-weight:700">${a(p.label)}</th>`).join("")}</tr></thead><tbody><tr>${z.figures.map(p=>`<td style="border:1px solid ${y};padding:${v};text-align:center;${p.emphasize?`font-weight:800;color:${m};`:""}">${a(p.value)}</td>`).join("")}</tr></tbody></table>`:"",O=z&&z.payways.length?`<table style="margin-top:8px"><thead><tr><th style="border:1px solid ${y};background:${S};color:${m};padding:${v};text-align:center;font-weight:700">${h("PayWay","\u0637\u0631\u064A\u0642\u0629 \u0627\u0644\u062F\u0641\u0639")}</th><th style="border:1px solid ${y};background:${S};color:${m};padding:${v};text-align:center;font-weight:700">${h("Total","\u0627\u0644\u0625\u062C\u0645\u0627\u0644\u064A")}</th><th style="border:1px solid ${y};background:${S};color:${m};padding:${v};text-align:center;font-weight:700">${h("Net","\u0627\u0644\u0635\u0627\u0641\u064A")}</th></tr></thead><tbody>${z.payways.map(p=>`<tr><td style="border:1px solid ${y};padding:${v};text-align:center;font-weight:600">${a(p.payway)}</td><td style="border:1px solid ${y};padding:${v};text-align:center">${a(p.total)}</td><td style="border:1px solid ${y};padding:${v};text-align:center;font-weight:700">${a(p.net)}</td></tr>`).join("")}</tbody></table>`:"",tt=M||O?`<div style="margin-top:16px;page-break-inside:avoid">
           <div style="font-weight:800;color:${m};font-size:${l?11:13}px;margin-bottom:6px">${h("Summary","\u0627\u0644\u0645\u0644\u062E\u0635")}</div>
           ${M}${O}
         </div>`:"";return`<!doctype html>
<html dir="${n}" lang="${t.lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${a(this.fileNameBase(t))}</title>
<style>
  body { font-family:'Tajawal','Segoe UI',Arial,sans-serif; margin:0; padding:${Q}; color:${at}; }
  table { border-collapse:collapse; width:100%; font-size:${G}px; ${o?"table-layout:fixed;":""} }
  th,td { mso-data-placement:same-cell; }
  .head-bar { padding-bottom:8px; margin-bottom:10px; border-bottom:3px solid ${m}; ${l?"text-align:center;":""} }
  .head-bar .brand { display:inline-flex; align-items:center; gap:8px; }
  .head-bar .logo { display:inline-flex; height:${l?18:26}px; width:${l?18:26}px; align-items:center; justify-content:center;
                    border-radius:6px; background:${m}; color:#fff; font-weight:800; font-size:${l?11:15}px; }
  .head-bar h1 { margin:0; font-size:${l?14:20}px; color:${m}; }
  .head-bar p { margin:2px 0 0; color:${j}; font-size:${l?10:12}px; }
  .meta { color:${j}; font-size:${l?10:12}px; margin:8px 0 6px; ${l?"text-align:center;":""} }
  .meta span { display:${l?"block":"inline"}; margin-${s?"left":"right"}:${l?"0":"18px"}; }
  .filters { margin:4px 0 12px; font-size:${l?9:11}px; ${l?"text-align:center;":""} }
  .filters-lead { color:${j}; font-weight:700; margin-${s?"left":"right"}:6px; }
  .chip { display:inline-block; margin:2px 4px 2px 0; padding:2px 8px; border-radius:999px;
          background:${S}; color:${m}; border:1px solid ${y}; white-space:nowrap; }
  .chip i { font-style:normal; color:${j}; font-weight:600; margin-${s?"left":"right"}:5px; }
  ${V}
</style>
</head>
<body dir="${n}">
  <div class="head-bar">
    <span class="brand"><span class="logo">A</span><h1>${a(c)}</h1></span>
    ${x?`<p>${a(x)}</p>`:""}
  </div>
  <div class="meta">${u.map(p=>`<span>${p}</span>`).join("")}</div>
  ${$}
  ${f?"":`<div class="hint noprint">${h('Use your browser print dialog \u2192 "Save as PDF".','\u0627\u0633\u062A\u062E\u062F\u0645 \u0646\u0627\u0641\u0630\u0629 \u0627\u0644\u0637\u0628\u0627\u0639\u0629 \u2190 "\u062D\u0641\u0638 \u0643\u0640 PDF".')}</div>`}
  <table dir="${n}">
    <colgroup>${Z}</colgroup>
    <thead><tr>${Y}</tr></thead>
    <tbody>${X||`<tr><td style="padding:18px;text-align:center;color:${j}" colspan="${e.length}">${h("No data.","\u0644\u0627 \u062A\u0648\u062C\u062F \u0628\u064A\u0627\u0646\u0627\u062A.")}</td></tr>`}</tbody>
    ${K}
  </table>
  ${tt}
</body>
</html>`}buildReceipt(r,e,t,i){let s=t.lang==="ar",n=s?"rtl":"ltr",f=s?t.titleAr:t.titleEn,l=s?t.subtitleAr||t.subtitleEn:t.subtitleEn||t.subtitleAr,c=(o,g)=>s?g:o,x=i==="pos72"?"72mm":"80mm",h=[];(t.fromDate||t.toDate)&&h.push(`<div class="m-row"><span>${c("Period","\u0627\u0644\u0641\u062A\u0631\u0629")}</span><b>${a((t.fromDate||"").slice(0,10))} \u2192 ${a((t.toDate||"").slice(0,10))}</b></div>`),t.branch&&h.push(`<div class="m-row"><span>${c("Branch","\u0627\u0644\u0641\u0631\u0639")}</span><b>${a(t.branch)}</b></div>`);for(let o of t.appliedFilters??[])o&&o.value&&String(o.value).trim()!==""&&h.push(`<div class="m-row"><span>${a(o.label)}</span><b>${a(o.value)}</b></div>`);h.push(`<div class="m-row"><span>${c("Records","\u0639\u062F\u062F \u0627\u0644\u0633\u062C\u0644\u0627\u062A")}</span><b>${r.length}</b></div>`);let E=e.map(o=>`<th class="${o.numeric?"num":""}">${a(s?o.headerAr:o.headerEn)}</th>`).join(""),d=e.map(o=>gt(o)),u=r.length?r.map(o=>`<tr>${e.map((g,C)=>`<td class="${g.numeric?"num":""}">${a(d[C]?this.receiptShort(g.value(o,t.lang)):g.value(o,t.lang))}</td>`).join("")}</tr>`).join(""):`<tr><td colspan="${e.length}" style="text-align:center;color:#999;padding:14px 0">${c("No data.","\u0644\u0627 \u062A\u0648\u062C\u062F \u0628\u064A\u0627\u0646\u0627\u062A.")}</td></tr>`,b=t.paymentTotals??[];!b.length&&t.footer&&t.footer.length===e.length&&(b=e.map((o,g)=>({c:o,v:t.footer[g]})).filter(o=>o.c.numeric&&o.v!=null&&String(o.v).trim()!=="").map(o=>({label:s?o.c.headerAr:o.c.headerEn,value:String(o.v),emphasize:/net|الصافي/i.test(`${o.c.headerEn}${o.c.headerAr}`)})));let $=b.map(o=>`<div class="t-row ${o.emphasize?"net":""}"><span>${a(o.label)}</span><span>${a(o.value)}</span></div>`).join("");return`<!doctype html>
<html dir="${n}" lang="${t.lang}">
<head>
<meta charset="utf-8">
<title>${a(this.fileNameBase(t))}</title>
<style>
  /* Thermal-optimised: pure black, heavy weights, solid lines. Receipt printers
     are 1-bit \u2014 any grey or colour is dithered into sparse dots that barely burn
     (that's why the old grey headers / red logo printed almost invisible). */
  @page { size: ${x} auto; margin: 3mm; }
  @media print { .noprint { display:none } body { -webkit-print-color-adjust:exact; print-color-adjust:exact } }
  * { box-sizing:border-box; }
  body { font-family:'Tajawal','Segoe UI',Arial,sans-serif; margin:0 auto; padding:6px; color:#000;
         width:${x}; font-size:12px; line-height:1.34; font-weight:600; }
  .r-time { text-align:center; color:#000; font-size:10.5px; font-weight:700; letter-spacing:.3px; margin-bottom:5px; }
  .r-head { text-align:center; border:2px solid #000; border-radius:8px; padding:9px 6px; margin-bottom:8px; }
  .r-head .logo { display:inline-flex; height:26px; width:26px; align-items:center; justify-content:center;
                  border-radius:6px; background:#000; color:#fff; font-weight:800; font-size:16px; margin-bottom:4px;
                  -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  .r-head h1 { margin:2px 0 0; font-size:18px; font-weight:800; letter-spacing:.2px; color:#000; }
  .r-head .sub { margin-top:2px; color:#000; font-size:11px; font-weight:700; }
  .r-meta { margin:0 0 6px; }
  .m-row { display:flex; justify-content:space-between; gap:8px; padding:2.5px; font-size:12px; }
  .m-row span { color:#000; font-weight:700; }
  .m-row b { color:#000; font-weight:800; text-align:${s?"left":"right"}; }
  .rule { border:0; border-top:2px solid #000; margin:6px 0; }
  table { width:100%; border-collapse:collapse; table-layout:fixed; }
  thead th { font-size:9.5px; text-transform:uppercase; letter-spacing:.2px; color:#000; font-weight:800;
             padding:4px 2px; border-bottom:2px solid #000; text-align:center;
             white-space:normal; overflow-wrap:anywhere; }
  tbody td { padding:5px 2px; border-bottom:1px dashed #000; vertical-align:middle; font-size:10px; font-weight:700;
             color:#000; text-align:center; white-space:normal; overflow-wrap:anywhere; }
  .num { font-variant-numeric:tabular-nums; white-space:nowrap; overflow-wrap:normal; }
  .r-totals { margin-top:8px; border-top:2px solid #000; padding-top:6px; }
  .t-row { display:flex; justify-content:space-between; padding:3.5px 2px; font-size:13px; font-weight:700; color:#000; }
  .t-row span:last-child { font-variant-numeric:tabular-nums; color:#000; font-weight:800; }
  .t-row.net { margin-top:4px; padding-top:6px; border-top:2px solid #000; font-size:16px; font-weight:800; color:#000; }
  .t-row.net span:last-child { color:#000; }
  .r-foot { text-align:center; color:#000; font-size:10.5px; font-weight:700; margin-top:10px; }
  .hint { text-align:center; color:#000; font-size:10px; margin:6px 0 10px; }
</style>
</head>
<body dir="${n}">
  <div class="r-time">${a(this.nowLabel())}</div>
  <div class="r-head">
    <div class="logo">A</div>
    <h1>${a(f)}</h1>
    ${l?`<div class="sub">${a(l)}</div>`:""}
  </div>
  <div class="r-meta">${h.join("")}</div>
  <hr class="rule">
  <div class="hint noprint">${c('Print \u2192 "Save as PDF" or send to the receipt printer.','\u0627\u0637\u0628\u0639 \u2190 "\u062D\u0641\u0638 \u0643\u0640 PDF" \u0623\u0648 \u0623\u0631\u0633\u0644 \u0644\u0637\u0627\u0628\u0639\u0629 \u0627\u0644\u0625\u064A\u0635\u0627\u0644\u0627\u062A.')}</div>
  <table>
    <thead><tr>${E}</tr></thead>
    <tbody>${u}</tbody>
  </table>
  ${$?`<div class="r-totals">${$}</div>`:""}
  <div class="r-foot">Apex Point of Sale \u2014 ${c("Thank you","\u0634\u0643\u0631\u0627\u064B \u0644\u0643")}</div>
</body>
</html>`}receiptShort(r){let e=r==null?"":String(r),t=e.trim().toLowerCase().replace(/[\s._-]/g,"");return ct[t]??e}download(r,e){let t=URL.createObjectURL(r),i=document.createElement("a");i.href=t,i.download=e,document.body.appendChild(i),i.click(),i.remove(),setTimeout(()=>URL.revokeObjectURL(t),1500)}egyptParts(){let r=new Date,e=new Intl.DateTimeFormat("en-GB",{timeZone:"Africa/Cairo",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:!0}).formatToParts(r),t=n=>e.find(f=>f.type===n)?.value??"",i=`${t("year")}-${t("month")}-${t("day")}`,s=(t("dayPeriod")||"").toUpperCase();return{date:i,time12:`${t("hour")}:${t("minute")}`,ampm:s}}nowLabel(){let r=this.egyptParts();return`${r.date}  ${r.time12} ${r.ampm}`}fileNameBase(r){let t=((r.lang==="ar"?r.titleAr:r.titleEn)||r.fileBase||"report").replace(/[\\/:*?"<>|]+/g," ").replace(/\s+/g," ").trim(),i=this.egyptParts();return`${t} - ${i.date} ${i.time12.replace(":",".")} ${i.ampm}`}fileName(r,e){return`${this.fileNameBase(r)}.${e}`}metaLines(r){let e=r.lang==="ar",t=(s,n)=>e?n:s,i=[];r.branch&&i.push(`${t("Branch","\u0627\u0644\u0641\u0631\u0639")}: ${r.branch}`),(r.fromDate||r.toDate)&&i.push(`${t("Period","\u0627\u0644\u0641\u062A\u0631\u0629")}: ${(r.fromDate||"").slice(0,10)} -> ${(r.toDate||"").slice(0,10)}`),i.push(`${t("Generated","\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062A\u0635\u062F\u064A\u0631")}: ${this.nowLabel()}`);for(let s of r.appliedFilters??[])s&&s.value&&String(s.value).trim()!==""&&i.push(`${s.label}: ${s.value}`);return i}static \u0275fac=function(e){return new(e||w)};static \u0275prov=U({token:w,factory:w.\u0275fac,providedIn:"root"})};function a(w){return String(w??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}export{_ as a};
